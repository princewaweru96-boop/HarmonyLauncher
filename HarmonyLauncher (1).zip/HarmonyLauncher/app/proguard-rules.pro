-keep class com.harmonylauncher.** { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
