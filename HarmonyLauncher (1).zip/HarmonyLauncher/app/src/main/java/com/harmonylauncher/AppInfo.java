package com.harmonylauncher;

import android.graphics.drawable.Drawable;

public class AppInfo {
    public String label;
    public String packageName;
    public String activityName;
    public Drawable icon;

    public AppInfo(String label, String packageName, String activityName, Drawable icon) {
        this.label = label;
        this.packageName = packageName;
        this.activityName = activityName;
        this.icon = icon;
    }
}
