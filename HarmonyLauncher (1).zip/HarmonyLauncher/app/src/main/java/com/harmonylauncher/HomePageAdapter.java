package com.harmonylauncher;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class HomePageAdapter extends RecyclerView.Adapter<HomePageAdapter.PageViewHolder> {

    private final Context context;
    private final List<AppInfo> apps;
    private final int appsPerPage;
    private final SharedPreferences prefs;

    public HomePageAdapter(Context ctx, List<AppInfo> apps, int appsPerPage, SharedPreferences prefs) {
        this.context = ctx;
        this.apps = apps;
        this.appsPerPage = appsPerPage;
        this.prefs = prefs;
    }

    @Override
    public int getItemCount() {
        if (apps.isEmpty()) return 1;
        return (int) Math.ceil((double) apps.size() / appsPerPage);
    }

    @NonNull
    @Override
    public PageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.page_home, parent, false);
        return new PageViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull PageViewHolder holder, int position) {
        int start = position * appsPerPage;
        int end = Math.min(start + appsPerPage, apps.size());
        List<AppInfo> pageApps = apps.subList(start, end);

        int cols = prefs.getInt("grid_columns", 4);
        holder.recyclerView.setLayoutManager(new GridLayoutManager(context, cols));
        AppGridAdapter adapter = new AppGridAdapter(context, pageApps, (MainActivity) context);
        holder.recyclerView.setAdapter(adapter);
        holder.recyclerView.setHasFixedSize(false);
    }

    static class PageViewHolder extends RecyclerView.ViewHolder {
        RecyclerView recyclerView;
        PageViewHolder(View v) {
            super(v);
            recyclerView = v.findViewById(R.id.rvAppGrid);
        }
    }
}
