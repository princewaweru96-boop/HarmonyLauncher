package com.harmonylauncher;

import android.content.Context;
import android.view.HapticFeedbackConstants;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AppGridAdapter extends RecyclerView.Adapter<AppGridAdapter.AppViewHolder> {

    private final Context context;
    private final List<AppInfo> apps;
    private final MainActivity launcher;

    public AppGridAdapter(Context ctx, List<AppInfo> apps, MainActivity launcher) {
        this.context = ctx;
        this.apps = apps;
        this.launcher = launcher;
    }

    @NonNull
    @Override
    public AppViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_app, parent, false);
        return new AppViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull AppViewHolder holder, int position) {
        AppInfo app = apps.get(position);
        holder.icon.setImageDrawable(app.icon);
        holder.label.setText(app.label);

        // Staggered entry animation
        holder.itemView.setAlpha(0f);
        holder.itemView.setScaleX(0.5f);
        holder.itemView.setScaleY(0.5f);
        holder.itemView.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(300)
            .setStartDelay(position * 30L)
            .setInterpolator(new OvershootInterpolator(1.2f))
            .start();

        // Tap to launch
        holder.itemView.setOnClickListener(v -> {
            // Press animation
            v.animate().scaleX(0.85f).scaleY(0.85f).setDuration(80).withEndAction(() ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(150)
                    .setInterpolator(new OvershootInterpolator()).start()
            ).start();
            v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
            launcher.launchApp(app);
        });

        // Long press for app info
        holder.itemView.setOnLongClickListener(v -> {
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            AppOptionsDialog.show(context, app, launcher);
            return true;
        });
    }

    @Override
    public int getItemCount() { return apps.size(); }

    static class AppViewHolder extends RecyclerView.ViewHolder {
        ImageView icon;
        TextView label;
        AppViewHolder(View v) {
            super(v);
            icon  = v.findViewById(R.id.appIcon);
            label = v.findViewById(R.id.appLabel);
        }
    }
}
