package com.harmonylauncher;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;

public class AppOptionsDialog {

    public static void show(Context context, AppInfo app, MainActivity launcher) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context, R.style.HarmonyDialog);
        View view = LayoutInflater.from(context).inflate(R.layout.dialog_app_options, null);
        builder.setView(view);
        AlertDialog dialog = builder.create();

        TextView tvAppName = view.findViewById(R.id.tvDialogAppName);
        View btnOpen       = view.findViewById(R.id.btnDialogOpen);
        View btnInfo       = view.findViewById(R.id.btnDialogInfo);
        View btnUninstall  = view.findViewById(R.id.btnDialogUninstall);
        View btnCancel     = view.findViewById(R.id.btnDialogCancel);

        if (tvAppName != null) tvAppName.setText(app.label);

        if (btnOpen != null) btnOpen.setOnClickListener(v -> {
            dialog.dismiss();
            if (launcher != null) launcher.launchApp(app);
        });

        if (btnInfo != null) btnInfo.setOnClickListener(v -> {
            dialog.dismiss();
            Intent i = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(Uri.parse("package:" + app.packageName));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
        });

        if (btnUninstall != null) btnUninstall.setOnClickListener(v -> {
            dialog.dismiss();
            Intent i = new Intent(Intent.ACTION_DELETE);
            i.setData(Uri.parse("package:" + app.packageName));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
        });

        if (btnCancel != null) btnCancel.setOnClickListener(v -> dialog.dismiss());

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }
        dialog.show();
    }
}
