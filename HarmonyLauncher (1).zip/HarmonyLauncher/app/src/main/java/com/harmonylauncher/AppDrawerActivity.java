package com.harmonylauncher;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AppDrawerActivity extends AppCompatActivity {

    private RecyclerView rvApps;
    private EditText etSearch;
    private List<AppInfo> allApps = new ArrayList<>();
    private List<AppInfo> filteredApps = new ArrayList<>();
    private AppGridAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Fullscreen immersive
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        );
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );

        setContentView(R.layout.activity_drawer);

        rvApps   = findViewById(R.id.rvDrawerApps);
        etSearch = findViewById(R.id.etSearch);

        findViewById(R.id.btnClose).setOnClickListener(v -> finish());

        loadApps();
        setupSearch();
    }

    private void loadApps() {
        new Thread(() -> {
            PackageManager pm = getPackageManager();
            Intent intent = new Intent(Intent.ACTION_MAIN, null);
            intent.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> ris = pm.queryIntentActivities(intent, 0);

            for (ResolveInfo ri : ris) {
                String pkg = ri.activityInfo.packageName;
                if (!pkg.equals(getPackageName())) {
                    allApps.add(new AppInfo(
                        ri.loadLabel(pm).toString(), pkg,
                        ri.activityInfo.name, ri.loadIcon(pm)
                    ));
                }
            }
            Collections.sort(allApps, (a, b) -> a.label.compareToIgnoreCase(b.label));
            filteredApps.addAll(allApps);

            runOnUiThread(() -> {
                rvApps.setLayoutManager(new GridLayoutManager(this, 4));
                adapter = new AppGridAdapter(this, filteredApps, (MainActivity) null) {
                    @Override
                    public void onBindViewHolder(AppViewHolder holder, int position) {
                        AppInfo app = filteredApps.get(position);
                        holder.icon.setImageDrawable(app.icon);
                        holder.label.setText(app.label);
                        holder.itemView.setOnClickListener(v -> launchApp(app));
                    }
                    @Override
                    public int getItemCount() { return filteredApps.size(); }
                };
                rvApps.setAdapter(adapter);
            });
        }).start();
    }

    private void launchApp(AppInfo app) {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(app.packageName);
            if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); finish(); }
        } catch (Exception ignored) {}
    }

    private void setupSearch() {
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void afterTextChanged(Editable s) {}
            @Override
            public void onTextChanged(CharSequence s, int st, int b, int c) {
                filteredApps.clear();
                String q = s.toString().toLowerCase().trim();
                if (q.isEmpty()) {
                    filteredApps.addAll(allApps);
                } else {
                    for (AppInfo app : allApps) {
                        if (app.label.toLowerCase().contains(q)) filteredApps.add(app);
                    }
                }
                if (adapter != null) adapter.notifyDataSetChanged();
            }
        });
    }

    @Override
    public void onBackPressed() { finish(); }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(0, R.anim.slide_down);
    }
}
