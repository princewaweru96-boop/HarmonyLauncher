package com.harmonylauncher;

import android.app.WallpaperManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import java.io.IOException;

public class SettingsActivity extends AppCompatActivity {

    private SharedPreferences prefs;

    // Theme cards
    private View cardDeepSpace, cardCrimson, cardForest, cardSunset,
                 cardOcean, cardSakura, cardMidnight, cardAurora;

    // Font size
    private SeekBar seekFontSize;
    private TextView tvFontPreview;

    // Grid
    private SeekBar seekColumns, seekRows;
    private TextView tvColumns, tvRows;

    // Wallpaper
    private static final int PICK_WALLPAPER = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        setContentView(R.layout.activity_settings);
        prefs = getSharedPreferences("harmony_prefs", Context.MODE_PRIVATE);

        setupBackButton();
        setupThemes();
        setupFontSize();
        setupGrid();
        setupWallpaper();
        setupIconShape();
        setupMiscToggles();
        loadCurrentSettings();
    }

    // ── BACK ──────────────────────────────────
    private void setupBackButton() {
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
    }

    // ── THEMES ────────────────────────────────
    private void setupThemes() {
        int[][] themes = {
            {R.id.cardDeepSpace,  R.color.theme_deep_space},
            {R.id.cardCrimson,    R.color.theme_crimson},
            {R.id.cardForest,     R.color.theme_forest},
            {R.id.cardSunset,     R.color.theme_sunset},
            {R.id.cardOcean,      R.color.theme_ocean},
            {R.id.cardSakura,     R.color.theme_sakura},
            {R.id.cardMidnight,   R.color.theme_midnight},
            {R.id.cardAurora,     R.color.theme_aurora},
        };
        String[] themeNames = {
            "Deep Space","Crimson","Forest","Sunset",
            "Ocean","Sakura","Midnight","Aurora"
        };
        String[] accentColors = {
            "#4FC3F7","#FF6B6B","#69F0AE","#FFD740",
            "#00E5FF","#F48FB1","#E040FB","#76FF03"
        };
        String[] accent2Colors = {
            "#CE93D8","#FF8E53","#00E5FF","#FF6B6B",
            "#00B0FF","#CE93D8","#7C4DFF","#00E5FF"
        };

        for (int i = 0; i < themes.length; i++) {
            final int idx = i;
            View card = findViewById(themes[i][0]);
            if (card == null) continue;
            card.setOnClickListener(v -> {
                applyTheme(themeNames[idx], accentColors[idx], accent2Colors[idx]);
                highlightThemeCard(themes[idx][0]);
                Toast.makeText(this, "Theme: " + themeNames[idx], Toast.LENGTH_SHORT).show();
            });
        }
    }

    private void applyTheme(String name, String accent, String accent2) {
        prefs.edit()
            .putString("theme_name", name)
            .putString("accent_color", accent)
            .putString("accent_color2", accent2)
            .apply();
    }

    private void highlightThemeCard(int cardId) {
        int[] allCards = {
            R.id.cardDeepSpace, R.id.cardCrimson, R.id.cardForest, R.id.cardSunset,
            R.id.cardOcean, R.id.cardSakura, R.id.cardMidnight, R.id.cardAurora
        };
        for (int id : allCards) {
            View c = findViewById(id);
            if (c != null) c.setAlpha(id == cardId ? 1f : 0.5f);
        }
    }

    // ── FONT SIZE ─────────────────────────────
    private void setupFontSize() {
        seekFontSize  = findViewById(R.id.seekFontSize);
        tvFontPreview = findViewById(R.id.tvFontPreview);
        if (seekFontSize == null) return;

        seekFontSize.setMax(3); // 0=Small 1=Normal 2=Large 3=XLarge
        seekFontSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean user) {
                String[] labels = {"Small", "Normal", "Large", "X-Large"};
                float[] scales  = {0.85f, 1.0f, 1.15f, 1.3f};
                if (tvFontPreview != null) tvFontPreview.setText("Preview: " + labels[p]);
                prefs.edit()
                    .putFloat("font_scale", scales[p])
                    .putString("font_size_label", labels[p])
                    .apply();
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });
    }

    // ── GRID SIZE ─────────────────────────────
    private void setupGrid() {
        seekColumns = findViewById(R.id.seekColumns);
        seekRows    = findViewById(R.id.seekRows);
        tvColumns   = findViewById(R.id.tvColumns);
        tvRows      = findViewById(R.id.tvRows);
        if (seekColumns == null) return;

        seekColumns.setMax(2); // 3,4,5 columns
        seekColumns.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean user) {
                int cols = p + 3;
                if (tvColumns != null) tvColumns.setText("Columns: " + cols);
                prefs.edit().putInt("grid_columns", cols).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });

        seekRows.setMax(2); // 4,5,6 rows
        seekRows.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean user) {
                int rows = p + 4;
                if (tvRows != null) tvRows.setText("Rows: " + rows);
                prefs.edit().putInt("grid_rows", rows).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });
    }

    // ── WALLPAPER ─────────────────────────────
    private void setupWallpaper() {
        View btnPickWp = findViewById(R.id.btnPickWallpaper);
        if (btnPickWp != null) {
            btnPickWp.setOnClickListener(v -> {
                Intent i = new Intent(Intent.ACTION_PICK);
                i.setType("image/*");
                startActivityForResult(i, PICK_WALLPAPER);
            });
        }
        // Built-in wallpaper gradient cards
        int[] wpCards = {R.id.wpCosmos, R.id.wpOcean, R.id.wpForest,
                         R.id.wpSunset, R.id.wpAurora, R.id.wpSakura};
        String[] wpNames = {"Cosmos","Ocean","Forest","Sunset","Aurora","Sakura"};
        for (int i = 0; i < wpCards.length; i++) {
            final String name = wpNames[i];
            View c = findViewById(wpCards[i]);
            if (c != null) c.setOnClickListener(v -> {
                prefs.edit().putString("wallpaper_type", "builtin")
                    .putString("wallpaper_name", name).apply();
                Toast.makeText(this, "Wallpaper: " + name, Toast.LENGTH_SHORT).show();
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_WALLPAPER && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            try {
                WallpaperManager wm = WallpaperManager.getInstance(this);
                wm.setStream(getContentResolver().openInputStream(uri));
                prefs.edit().putString("wallpaper_type","custom")
                    .putString("wallpaper_uri", uri.toString()).apply();
                Toast.makeText(this, "Wallpaper set!", Toast.LENGTH_SHORT).show();
            } catch (IOException e) {
                Toast.makeText(this, "Failed to set wallpaper", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // ── ICON SHAPE ────────────────────────────
    private void setupIconShape() {
        View[] shapes = {
            findViewById(R.id.shapeRounded),
            findViewById(R.id.shapeSquare),
            findViewById(R.id.shapeCircle)
        };
        String[] shapeNames = {"rounded","square","circle"};
        for (int i = 0; i < shapes.length; i++) {
            if (shapes[i] == null) continue;
            final String sn = shapeNames[i];
            shapes[i].setOnClickListener(v -> {
                prefs.edit().putString("icon_shape", sn).apply();
                Toast.makeText(this, "Icon shape: " + sn, Toast.LENGTH_SHORT).show();
                highlightShape(v, shapes);
            });
        }
    }

    private void highlightShape(View selected, View[] all) {
        for (View v : all) { if (v != null) v.setAlpha(0.4f); }
        if (selected != null) selected.setAlpha(1f);
    }

    // ── MISC TOGGLES ─────────────────────────
    private void setupMiscToggles() {
        Switch swDark     = findViewById(R.id.swDarkMode);
        Switch swBadges   = findViewById(R.id.swBadges);
        Switch swClock    = findViewById(R.id.swShowClock);
        Switch swAnimations = findViewById(R.id.swAnimations);

        if (swDark != null) swDark.setOnCheckedChangeListener((b, checked) ->
            prefs.edit().putBoolean("dark_mode", checked).apply());
        if (swBadges != null) swBadges.setOnCheckedChangeListener((b, checked) ->
            prefs.edit().putBoolean("show_badges", checked).apply());
        if (swClock != null) swClock.setOnCheckedChangeListener((b, checked) ->
            prefs.edit().putBoolean("show_clock", checked).apply());
        if (swAnimations != null) swAnimations.setOnCheckedChangeListener((b, checked) ->
            prefs.edit().putBoolean("animations", checked).apply());
    }

    // ── LOAD SAVED ───────────────────────────
    private void loadCurrentSettings() {
        // Font size
        if (seekFontSize != null) {
            float scale = prefs.getFloat("font_scale", 1.0f);
            int prog = scale <= 0.85f ? 0 : scale <= 1.0f ? 1 : scale <= 1.15f ? 2 : 3;
            seekFontSize.setProgress(prog);
        }
        // Grid
        if (seekColumns != null) seekColumns.setProgress(prefs.getInt("grid_columns", 4) - 3);
        if (seekRows != null)    seekRows.setProgress(prefs.getInt("grid_rows", 5) - 4);

        // Toggles
        Switch swDark   = findViewById(R.id.swDarkMode);
        Switch swBadges = findViewById(R.id.swBadges);
        Switch swClock  = findViewById(R.id.swShowClock);
        Switch swAnim   = findViewById(R.id.swAnimations);
        if (swDark   != null) swDark.setChecked(prefs.getBoolean("dark_mode", true));
        if (swBadges != null) swBadges.setChecked(prefs.getBoolean("show_badges", true));
        if (swClock  != null) swClock.setChecked(prefs.getBoolean("show_clock", true));
        if (swAnim   != null) swAnim.setChecked(prefs.getBoolean("animations", true));
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(0, R.anim.slide_down);
    }
}
