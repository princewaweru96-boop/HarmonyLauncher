package com.harmonylauncher;

import android.content.Context;
import android.view.HapticFeedbackConstants;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DockAdapter extends RecyclerView.Adapter<DockAdapter.DockViewHolder> {

    private final Context context;
    private final List<AppInfo> apps;

    public DockAdapter(Context ctx, List<AppInfo> apps) {
        this.context = ctx;
        this.apps = apps;
    }

    @NonNull
    @Override
    public DockViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_dock, parent, false);
        return new DockViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull DockViewHolder holder, int position) {
        AppInfo app = apps.get(position);
        holder.icon.setImageDrawable(app.icon);

        holder.itemView.setOnClickListener(v -> {
            v.animate().scaleX(0.8f).scaleY(0.8f).setDuration(80).withEndAction(() ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(200)
                    .setInterpolator(new OvershootInterpolator(2f)).start()
            ).start();
            v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
            ((MainActivity) context).launchApp(app);
        });

        holder.itemView.setOnLongClickListener(v -> {
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            AppOptionsDialog.show(context, app, (MainActivity) context);
            return true;
        });
    }

    @Override
    public int getItemCount() { return apps.size(); }

    static class DockViewHolder extends RecyclerView.ViewHolder {
        ImageView icon;
        DockViewHolder(View v) {
            super(v);
            icon = v.findViewById(R.id.dockIcon);
        }
    }
}
