package com.harmonylauncher;

import android.app.WallpaperManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.format.DateFormat;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    // Views
    private ViewPager2 viewPager;
    private TextView tvTime, tvDate, tvBattery;
    private RecyclerView rvDock;
    private View btnSettings, btnDrawer;

    // Data
    private List<AppInfo> allApps = new ArrayList<>();
    private List<AppInfo> dockApps = new ArrayList<>();
    private HomePageAdapter homePagerAdapter;
    private DockAdapter dockAdapter;

    // State
    private Handler clockHandler = new Handler(Looper.getMainLooper());
    private Runnable clockRunnable;
    private SharedPreferences prefs;
    private BroadcastReceiver packageReceiver;
    private BroadcastReceiver batteryReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Make launcher truly fullscreen - hide system status bar
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        );
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );

        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("harmony_prefs", Context.MODE_PRIVATE);

        initViews();
        loadApps();
        setupClock();
        setupBatteryReceiver();
        setupPackageReceiver();
        applyTheme();
    }

    private void initViews() {
        viewPager      = findViewById(R.id.viewPager);
        tvTime         = findViewById(R.id.tvTime);
        tvDate         = findViewById(R.id.tvDate);
        tvBattery      = findViewById(R.id.tvBattery);
        rvDock         = findViewById(R.id.rvDock);
        btnSettings    = findViewById(R.id.btnSettings);
        btnDrawer      = findViewById(R.id.btnDrawer);

        btnSettings.setOnClickListener(v -> openSettings());
        btnDrawer.setOnClickListener(v -> openDrawer());

        // Long press on home opens settings
        viewPager.setOnLongClickListener(v -> {
            openSettings();
            return true;
        });
    }

    // ─────────────────────────────────────────
    // LOAD ALL REAL INSTALLED APPS
    // ─────────────────────────────────────────
    private void loadApps() {
        new Thread(() -> {
            PackageManager pm = getPackageManager();
            Intent intent = new Intent(Intent.ACTION_MAIN, null);
            intent.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> resolveInfos = pm.queryIntentActivities(intent, 0);

            List<AppInfo> apps = new ArrayList<>();
            for (ResolveInfo ri : resolveInfos) {
                String label = ri.loadLabel(pm).toString();
                String packageName = ri.activityInfo.packageName;
                String activityName = ri.activityInfo.name;
                Drawable icon = ri.loadIcon(pm);

                // Skip our own launcher from the list
                if (!packageName.equals(getPackageName())) {
                    apps.add(new AppInfo(label, packageName, activityName, icon));
                }
            }

            // Sort alphabetically
            Collections.sort(apps, (a, b) -> a.label.compareToIgnoreCase(b.label));
            allApps = apps;

            // Build dock apps (first 4 or saved dock)
            buildDockApps();

            runOnUiThread(() -> {
                setupViewPager();
                setupDock();
            });
        }).start();
    }

    private void buildDockApps() {
        dockApps.clear();
        // Try to get phone, messages, camera, browser from real apps
        String[] preferredDock = {"com.android.dialer", "com.google.android.dialer",
            "com.samsung.android.dialer", "com.android.mms", "com.google.android.apps.messaging",
            "com.samsung.android.messaging", "com.android.camera2", "com.google.android.camera",
            "com.android.chrome", "com.google.android.apps.photos"};

        List<String> addedPackages = new ArrayList<>();
        for (String pkg : preferredDock) {
            if (addedPackages.size() >= 4) break;
            for (AppInfo app : allApps) {
                if (app.packageName.equals(pkg) && !addedPackages.contains(pkg)) {
                    dockApps.add(app);
                    addedPackages.add(pkg);
                    break;
                }
            }
        }
        // Fill remaining dock slots with first apps
        for (AppInfo app : allApps) {
            if (dockApps.size() >= 4) break;
            if (!addedPackages.contains(app.packageName)) {
                dockApps.add(app);
                addedPackages.add(app.packageName);
            }
        }
    }

    // ─────────────────────────────────────────
    // SETUP HOME PAGES (ViewPager)
    // ─────────────────────────────────────────
    private void setupViewPager() {
        int appsPerPage = prefs.getInt("grid_columns", 4) * prefs.getInt("grid_rows", 5);
        homePagerAdapter = new HomePageAdapter(this, allApps, appsPerPage, prefs);
        viewPager.setAdapter(homePagerAdapter);
        viewPager.setOffscreenPageLimit(3);

        // Page indicator dots
        setupPageDots(homePagerAdapter.getItemCount());

        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                updatePageDots(position);
            }
        });
    }

    private void setupDock() {
        int cols = Math.min(dockApps.size(), 5);
        rvDock.setLayoutManager(new GridLayoutManager(this, cols));
        dockAdapter = new DockAdapter(this, dockApps);
        rvDock.setAdapter(dockAdapter);
    }

    private void setupPageDots(int count) {
        // Handled in layout with dynamic dots
    }

    private void updatePageDots(int selected) {
        // Implemented in adapter
    }

    // ─────────────────────────────────────────
    // CLOCK
    // ─────────────────────────────────────────
    private void setupClock() {
        clockRunnable = new Runnable() {
            @Override
            public void run() {
                updateClock();
                clockHandler.postDelayed(this, 1000);
            }
        };
        clockHandler.post(clockRunnable);
    }

    private void updateClock() {
        Calendar cal = Calendar.getInstance();
        boolean is24h = DateFormat.is24HourFormat(this);
        String timeFormat = is24h ? "HH:mm" : "hh:mm";
        String time = new SimpleDateFormat(timeFormat, Locale.getDefault()).format(cal.getTime());
        String date = new SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(new Date());
        tvTime.setText(time);
        tvDate.setText(date);
    }

    // ─────────────────────────────────────────
    // BATTERY
    // ─────────────────────────────────────────
    private void setupBatteryReceiver() {
        batteryReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context ctx, Intent intent) {
                int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                if (level >= 0 && scale > 0) {
                    int pct = (int)((level / (float) scale) * 100);
                    tvBattery.setText(pct + "%");
                }
            }
        };
        registerReceiver(batteryReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
    }

    // ─────────────────────────────────────────
    // PACKAGE CHANGES (install/uninstall)
    // ─────────────────────────────────────────
    private void setupPackageReceiver() {
        packageReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context ctx, Intent intent) {
                loadApps(); // Reload all apps when packages change
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_PACKAGE_ADDED);
        filter.addAction(Intent.ACTION_PACKAGE_REMOVED);
        filter.addAction(Intent.ACTION_PACKAGE_CHANGED);
        filter.addDataScheme("package");
        registerReceiver(packageReceiver, filter);
    }

    // ─────────────────────────────────────────
    // LAUNCH APP
    // ─────────────────────────────────────────
    public void launchApp(AppInfo app) {
        try {
            PackageManager pm = getPackageManager();
            Intent launchIntent = pm.getLaunchIntentForPackage(app.packageName);
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(launchIntent);
                overridePendingTransition(R.anim.scale_in, R.anim.fade_out);
            } else {
                Toast.makeText(this, "Cannot open " + app.label, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Error opening app", Toast.LENGTH_SHORT).show();
        }
    }

    // ─────────────────────────────────────────
    // NAVIGATION
    // ─────────────────────────────────────────
    private void openSettings() {
        startActivity(new Intent(this, SettingsActivity.class));
        overridePendingTransition(R.anim.slide_up, R.anim.fade_out);
    }

    private void openDrawer() {
        startActivity(new Intent(this, AppDrawerActivity.class));
        overridePendingTransition(R.anim.slide_up, R.anim.fade_out);
    }

    // ─────────────────────────────────────────
    // THEME
    // ─────────────────────────────────────────
    public void applyTheme() {
        String accent = prefs.getString("accent_color", "#4FC3F7");
        // Apply accent to views
        try {
            int color = Color.parseColor(accent);
            // Applied via theme/style system
        } catch (Exception ignored) {}
    }

    // ─────────────────────────────────────────
    // BACK BUTTON - go home
    // ─────────────────────────────────────────
    @Override
    public void onBackPressed() {
        viewPager.setCurrentItem(0, true);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Re-hide system UI on resume
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );
        if (homePagerAdapter != null) homePagerAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        clockHandler.removeCallbacks(clockRunnable);
        if (packageReceiver != null) unregisterReceiver(packageReceiver);
        if (batteryReceiver != null) unregisterReceiver(batteryReceiver);
    }
}
