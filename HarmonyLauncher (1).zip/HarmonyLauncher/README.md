# HarmonyOS NEXT Launcher
### Full Android Launcher — Shows YOUR Real Installed Apps

---

## What This Does
- Reads ALL your real installed apps automatically
- Shows them in a HarmonyOS-style grid
- Replaces your home screen completely
- Real swipe between pages
- Long press apps → Open / Info / Uninstall
- Full Settings: 8 Themes, Wallpaper picker, Icon shapes, Font size, Grid size
- Immersive fullscreen — hides Android status bar, shows HarmonyOS status bar
- Works on ANY Android phone (Android 8.0+)

---

## HOW TO BUILD THE APK (Free — Step by Step)

### STEP 1 — Install Android Studio (Free)
1. Go to: https://developer.android.com/studio
2. Download and install Android Studio
3. When it opens, let it download the Android SDK (takes ~5 mins)

### STEP 2 — Open This Project
1. Open Android Studio
2. Click **"Open"** (not "New Project")
3. Navigate to the **HarmonyLauncher** folder you downloaded
4. Click **OK** — wait for Gradle to sync (~2 mins)

### STEP 3 — Build the APK
1. In Android Studio, click the top menu: **Build → Build Bundle(s)/APK(s) → Build APK(s)**
2. Wait for it to build (~1-2 mins)
3. A notification will pop up saying **"APK generated"**
4. Click **"locate"** to find the APK file

The APK will be at:
```
HarmonyLauncher/app/build/outputs/apk/debug/app-debug.apk
```

### STEP 4 — Install on Your Phone
**Option A — USB Cable:**
1. Connect phone to PC with USB
2. Enable "Developer Options" on phone:
   - Settings → About Phone → tap "Build Number" 7 times
3. Enable "USB Debugging" in Developer Options
4. In Android Studio click the **▶ Run** button — installs directly!

**Option B — File Transfer:**
1. Copy `app-debug.apk` to your phone (via USB, email, Google Drive, WhatsApp)
2. On your phone, open the APK file
3. If asked, enable "Install from unknown sources" → Settings → Security → Unknown Sources
4. Tap Install

### STEP 5 — Set as Default Launcher
1. After installing, press your phone's **Home button**
2. A popup asks "Which app to use as Home?"
3. Select **"HarmonyOS Launcher"**
4. Tap **"Always"**
5. Done! Your phone now runs HarmonyOS launcher with ALL your real apps!

---

## FEATURES

### Home Screen
- Swipe left/right between pages of your real apps
- All your installed apps appear automatically
- Long press any app for options
- Clock widget at top
- Custom dock at bottom

### Settings (Long press empty space)
- **8 Themes:** Deep Space, Crimson, Forest, Sunset, Ocean, Sakura, Midnight, Aurora
- **Wallpaper:** Upload any photo from your gallery
- **Icon Shape:** Rounded, Square, Circle
- **Font Size:** Small, Normal, Large, X-Large
- **Grid Size:** 3-5 columns, 4-6 rows
- **Toggles:** Dark mode, Badges, Clock widget, Animations

### App Drawer
- Tap the grid button in dock
- Shows ALL installed apps alphabetically
- Search bar to find any app instantly

---

## SWITCHING BACK TO YOUR OLD LAUNCHER
Settings → Apps → Default Apps → Home App → Select your old launcher

---

## REQUIREMENTS
- Android 8.0 (Oreo) or higher
- Any Android phone — Samsung, Xiaomi, OnePlus, Realme, etc.
- ~5MB storage

---

Built with ❤️ by Claude AI
HarmonyOS NEXT 5.0 inspired launcher
